// Copyright (C) 2014-2105 Xilinx Inc.
// All rights reserved.
// Author: soeren/sonal
//
/*  ---  Steps to run  ----
 * -- task.h is required. It is released by "datafiles" target, next two steps.
 * % cd src/products/sdaccel/src/runtime_src/xrt
 * % rdi make product=sdaccel datafiles
 * % cd fisusr/sdaccel/sprite/lowlevel/01_pcie_bw_async
 * -- Modify <path> to your workspace, where xclhal.h and task.h are located.
 * -- g++ must be 4.8.0 or later.  We can use g++ from batonroot. 
 * %  /tools/batonroot/rodin/devkits/lnx64/gcc-4.8.0/bin/g++ -O3 -std=c++0x main.cpp ../host_src/*.cpp -I ../host_src -I <path>/prep/rdi/sdaccel/runtime/driver/include -ldl -pthread 
 * -- Optional : if you get GLIB issues, tailor the "setenv" as per applicable : setenv LD_LIBRARY_PATH //proj/xbuilds/2015.3_sdaccel_daily_latest/installs/lin64/SDAccel/2015.3/lib/lnx64.o 
 * % ./a.out -s /proj/xbuilds/2015.3_sdaccel_daily_latest/installs/lin64/SDAccel/2015.3/data/sdaccel/pcie/x86_64/libvc690drv.so
 *
 */
#include <getopt.h>
#include <iostream>
#include <stdexcept>
#include <list>

#include "xclUtils.h"

// For asynchronous execution of xclHALProxy operations
#include "xclHALProxyAsync.h"

/**
 * Measures bus bandwidth between host and device memory. Does not use OpenCL runtime
 * but directly exercises the HAL driver API.
 */

const static struct option long_options[] = {
    {"hal_driver",        required_argument, 0, 's'},
    {"bitstream",         required_argument, 0, 'k'},
    {"hal_logfile",       required_argument, 0, 'l'},
    {"alignment",         required_argument, 0, 'a'},
    {"verbose",           no_argument,       0, 'v'},
    {"help",              no_argument,       0, 'h'},
    {0, 0, 0, 0}
};

static void printHelp()
{
    std::cout << "usage: %s [options]\n\n";
    std::cout << "  -s <hal_driver>\n";
    std::cout << "  -k <bitstream>\n";
    std::cout << "  -l <hal_logfile>\n";
    std::cout << "  -a <alignment>\n";
    std::cout << "  -v\n";
    std::cout << "  -h\n\n";
    std::cout << "* If HAL driver is not specified, application will try to find the HAL driver\n";
    std::cout << "  using XILINX_OPENCL and XCL_PLATFORM environment variables\n";
    std::cout << "* Bitstream is optional for PR platforms since they already have the base platform\n";
    std::cout << "  hardened and can do the DMA all by themselves\n";
    std::cout << "* HAL logfile is optional but useful for capturing messages from HAL driver\n";
}

static int transferSizeTest(xclHALProxyAsync &proxy, size_t alignment, unsigned maxSize)
{
    AlignedAllocator<unsigned> buf1(alignment, maxSize);
    AlignedAllocator<unsigned> buf2(alignment, maxSize);

    unsigned *writeBuffer = buf1.getBuffer();
    unsigned *readBuffer = buf2.getBuffer();

    for(unsigned j = 0; j < maxSize/4; j++){
        writeBuffer[j] = std::rand();
        readBuffer[j] = 0;
    }

    std::cout << "Running transfer test with various buffer sizes...\n";

    size_t size = 128;
    bool flag = true;
    for (unsigned i = 0; flag; i++) {
        size <<= i;
        if (size > maxSize) {
            size = maxSize;
            flag = false;
        }
        std::cout << "Size " << size << " B\n";
        uint64_t pos = proxy.allocateDevice(size);
        auto t1 = proxy.addTask(&xclHALProxyAsync::migrateHost2Device,pos,writeBuffer,size);
        std::memset(readBuffer, 0, size);
        if (t1.get() < 0) {
            std::cout << "FAILED TEST\n";
            std::cout << size << " B write failed\n";
            return 1;
        }
        auto t2 = proxy.addTask(&xclHALProxyAsync::migrateDevice2Host,pos,readBuffer,size);
        if (t2.get() < 0) {
            std::cout << "FAILED TEST\n";
            std::cout << size << " B read failed\n";
            return 1;
        }
        if (std::memcmp(writeBuffer, readBuffer, size)) {
            std::cout << "FAILED TEST\n";
            std::cout << size << " B verification failed\n";
            return 1;
        }
        proxy.freeDevice(pos);
    }

    return 0;
}

static int transferBenchmarkTest(xclHALProxyAsync &proxy, size_t alignment, unsigned blockSize, unsigned count)
{
    AlignedAllocator<unsigned> buf1(alignment, blockSize);
    AlignedAllocator<unsigned> buf2(alignment, blockSize);

    unsigned *writeBuffer = buf1.getBuffer();
    unsigned *readBuffer = buf2.getBuffer();

    for(unsigned j = 0; j < blockSize/4; j++) {
        writeBuffer[j] = std::rand();
        readBuffer[j] = 0;
    }

    std::list<uint64_t> deviceHandleList;

    unsigned long long totalData = 0;
    // First try with data verification

    std::cout << "Running benchmark tests...\nWriting/reading " << count << " blocks of " << blockSize / 1024 << " KB\n";
    for (int i = 0; i < count; i++)
    {
        uint64_t writeOffset =  proxy.allocateDevice(blockSize);
        if (writeOffset == -1) {
            std::cout << "FAILED TEST\n";
            std::cout << "Could not allocate device buffer\n";
            return 1;
        }
        deviceHandleList.push_back(writeOffset);

        auto t1 = proxy.addTask(&xclHALProxyAsync::migrateHost2Device,writeOffset,writeBuffer,blockSize);
        std::memset(readBuffer, 0, blockSize);
        size_t result = t1.get();
        if (result < 0) {
            std::cout << "FAILED TEST\n";
            std::cout << blockSize/1024 << " KB write failed\n";
            return 1;
        }

        auto t2 = proxy.addTask(&xclHALProxy::migrateDevice2Host,writeOffset,readBuffer,blockSize);
        result = t2.get();
        if (result < 0) {
            std::cout << "FAILED TEST\n";
            std::cout << blockSize/1024 << " KB read failed\n";
            return 1;
        }
        if (std::memcmp(writeBuffer, readBuffer, blockSize)) {
            std::cout << "FAILED TEST\n";
            std::cout << blockSize/1024 << " KB read/write verification failed\n";
            return 1;
        }
        totalData += blockSize;
    }

    totalData = 0;
    Timer myclock;

    std::vector<xclHALProxyAsync::event<size_t>> events;

    for (std::list<uint64_t>::const_iterator i = deviceHandleList.begin(), e = deviceHandleList.end(); i != e; ++i)
    {
        uint64_t writeOffset = *i;
        // No data integrity
        events.push_back(proxy.addTask(&xclHALProxyAsync::migrateHost2Device,writeOffset,writeBuffer,blockSize));
        events.push_back(proxy.addTask(&xclHALProxy::migrateDevice2Host,writeOffset,readBuffer,blockSize));
        totalData += blockSize;
    }

    // Wait for all writes and reads
    size_t result = 0;
    for (auto& e : events)
      result += e.get();

    double totalTime = myclock.stop();
    totalData *= 2; // account for both read and write

    if (result != totalData) {
      std::cout << "FAILED TEST\n";
      std::cout << blockSize/1024 << " KB read failed\n";
      return 1;
    }
    totalData /= 1024000;

    std::cout << "Host <-> Device PCIe RW bandwidth = " << totalData/totalTime << " MB/s\n";

    for (std::list<uint64_t>::const_iterator i = deviceHandleList.begin(), e = deviceHandleList.end(); i != e; ++i)
    {
        proxy.freeDevice(*i);
    }
    return 0;
}


int main(int argc, char** argv)
{
    std::string sharedLibrary;
    std::string bitstreamFile;
    std::string halLogfile;
    size_t alignment = 128;
    int option_index = 0;
    bool verbose = false;
    int c;
    findSharedLibrary(sharedLibrary);
    while ((c = getopt_long(argc, argv, "s:k:l:a:vh", long_options, &option_index)) != -1)
    {
        switch (c)
        {
        case 0:
            if (long_options[option_index].flag != 0)
                break;
        case 's':
            sharedLibrary = optarg;
            break;
        case 'k':
            bitstreamFile = optarg;
            break;
        case 'l':
            halLogfile = optarg;
            break;
        case 'a':
            alignment = std::atoi(optarg);
            break;
        case 'h':
            printHelp();
            return 0;
        case 'v':
            verbose = true;
            break;
        default:
            printHelp();
            return 1;
        }
    }

    (void)verbose;
    if (sharedLibrary.size() == 0) {
        std::cout << "FAILED TEST\n";
        std::cout << "No shared library specified and library couldnot be found using XILINX_OPENCL and XCL_PLATFORM environment variables\n";
        return -1;
    }

    if (bitstreamFile.size() == 0) {
        std::cout << "No bitstream specified and hence no bitstream will be loaded\n";
    }

    if (halLogfile.size()) {
        std::cout << "Using " << halLogfile << " as HAL driver logfile\n";
    }

    std::cout << "HAL driver = " << sharedLibrary << "\n";
    std::cout << "Host buffer alignment = " << alignment << " bytes\n";

    int retval = 0;

    try {
        xclHALProxyAsync proxy(sharedLibrary.c_str(), bitstreamFile.c_str(), halLogfile.c_str());

        // Max size is 8 MB
        if (transferSizeTest(proxy, alignment, 0x7D0000) != 0) {
            throw "FAILED_TEST";
        }

        // BlockSize = 16 KB, 245760 blocks
        if (transferBenchmarkTest(proxy, alignment, 0x3E80, 245760) != 0) {
            throw "FAILED_TEST";
        }

        // BlockSize = 256 KB, 15360 blocks
        if (transferBenchmarkTest(proxy, alignment, 0x3E800, 15360) != 0) {
            throw "FAILED_TEST";
        }

        // BlockSize = 8 MB, 480 blocks
        if (transferBenchmarkTest(proxy, alignment, 0x7D0000, 480) != 0) {
            throw "FAILED_TEST";
        }

        // BlockSize = 16 MB, 240 blocks
        if (transferBenchmarkTest(proxy, alignment, 0xFA0000, 240) != 0) {
            throw "FAILED_TEST";
        }

        // BlockSize = 64 MB, 60 blocks
        if (transferBenchmarkTest(proxy, alignment, 0x3E80000, 60) != 0) {
            throw "FAILED_TEST";
        }


        // BlockSize = 128 MB, 30 blocks
        if (transferBenchmarkTest(proxy, alignment, 0x7D00000, 30) != 0) {
            throw "FAILED_TEST";
        }


        // BlockSize = 256 MB, 15 blocks
        if (transferBenchmarkTest(proxy, alignment, 0xFA00000, 15) != 0) {
            throw "FAILED_TEST";
        }
    }
    catch (const char* str) {
       std::cout << str << "\n";
       retval = 1;
    }
    catch (std::exception const& e)
    {
        std::cout << "Exception: " << e.what() << "\n";
        std::cout << "FAILED TEST\n";
        retval = 1;
    }

    if (retval==0)
      std::cout << "PASSED TEST\n";

    return retval;
}


//Output will be something like:
/*
//No bitstream specified and hence no bitstream will be loaded
//HAL driver = /proj/xbuilds/2015.3_sdaccel_daily_latest/installs/lin64/SDAccel/2015.3/data/sdaccel/pcie/x86_64/libvc690drv.so
//Host buffer alignment = 128 bytes
//Running transfer test with various buffer sizes...
//Size 128 B
//Size 256 B
//Size 1024 B
//Size 8192 B
//Size 131072 B
//Size 4194304 B
//Size 8192000 B
//Running benchmark tests...
//Writing/reading 245760 blocks of 15 KB
//Host <-> Device PCIe RW bandwidth = 675.763 MB/s
//Running benchmark tests...
//Writing/reading 15360 blocks of 250 KB
//Host <-> Device PCIe RW bandwidth = 4120.17 MB/s
//Running benchmark tests...
//Writing/reading 480 blocks of 8000 KB
//Host <-> Device PCIe RW bandwidth = 6103.91 MB/s
//Running benchmark tests...
//Writing/reading 240 blocks of 16000 KB
//Host <-> Device PCIe RW bandwidth = 6726.79 MB/s
//Running benchmark tests...
//Writing/reading 60 blocks of 64000 KB
//Host <-> Device PCIe RW bandwidth = 5905.01 MB/s
//Running benchmark tests...
//Writing/reading 30 blocks of 128000 KB
//Host <-> Device PCIe RW bandwidth = 5878.75 MB/s
//Running benchmark tests...
//Writing/reading 15 blocks of 256000 KB
//Host <-> Device PCIe RW bandwidth = 5903.39 MB/s
//total work: 1047794
//total waits: 523920
//PASSED TEST
*/
