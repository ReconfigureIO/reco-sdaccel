// Copyright (C) 2014-2016 Xilinx Inc.
// All rights reserved.
// Author: sonals

#include <getopt.h>
#include <iostream>
#include <stdexcept>

#include <unistd.h>
#include "xclHALProxy.h"
#include "xclUtils.h"
#if defined(DSA64)
#include "xloopback_hw_64.h"
#else
#include "xloopback_hw.h"
#endif

static const int count = 1024;

struct Buffers {
    char *hostBuf1; // arg 0 buffer
    char *hostBuf2; // arg 1 buffer
    uint64_t deviceBuf1;
    uint64_t deviceBuf2;
    char *scratch;
    int foo;

    Buffers(size_t alignment) : hostBuf1(0), hostBuf2(0),
                                scratch(0) {
        posix_memalign((void **)&hostBuf1, alignment, count);
        posix_memalign((void **)&hostBuf2, alignment, count);
        posix_memalign((void **)&scratch, alignment, count);

        std::memset(hostBuf1, 0, 1024);
        std::memset(hostBuf1, 0, 1024);
        std::memset(scratch, 0, 1024);
    }

    ~Buffers() {
        free(hostBuf1);
        free(hostBuf2);
        free(scratch);
    }

    size_t size() const {
        return count;
    }
};


static int setupBuffers(xclHALProxy &proxy, Buffers &buffers)
{
    // Write out arg 0 buffer
    buffers.deviceBuf1 = proxy.allocateDevice(buffers.size());
    if (buffers.deviceBuf1 == 0xffffffffffffffff) {
        std::cout << "FAILED TEST\n";
        std::cout << "Could not allocate device buffer\n";
        return -1;
    }
    size_t result = proxy.migrateHost2Device(buffers.deviceBuf1, buffers.hostBuf1, buffers.size());
    if (result != buffers.size()) {
        std::cout << "FAILED TEST\n";
        std::cout << "Write failed\n";
        return -1;
    }

    // Verify if we could write arg 0
    result = proxy.migrateDevice2Host(buffers.deviceBuf1, buffers.scratch, buffers.size());
    if (result != buffers.size()) {
        std::cout << "FAILED TEST\n";
        std::cout << "Read failed\n";
        return -1;
    }

    if (std::memcmp(buffers.hostBuf1, buffers.scratch, buffers.size())) {
        std::cout << "FAILED TEST\n";
        std::cout << "Value read back does not match value written\n";
        return -1;
    }

    // Write out arg 1
    buffers.deviceBuf2 = proxy.allocateDevice(buffers.size());
    if (buffers.deviceBuf2 == 0xffffffffffffffff) {
        std::cout << "FAILED TEST\n";
        std::cout << "Could not allocate device buffer\n";
        return -1;
    }

    std::strcpy(buffers.hostBuf2, "hello\nthis is Xilinx OpenCL memory read write test\n:-)\n");

    result = proxy.migrateHost2Device(buffers.deviceBuf2, buffers.hostBuf2, buffers.size());
    if (result != buffers.size()) {
        std::cout << "FAILED TEST\n";
        std::cout << "Write failed\n";
        return -1;
    }

    // Verify if we could write arg 1
    result = proxy.migrateDevice2Host(buffers.deviceBuf2, buffers.scratch, buffers.size());
    if (result != buffers.size()) {
        std::cout << "FAILED TEST\n";
        std::cout << "Read failed\n";
        return -1;
    }

    if (std::memcmp(buffers.hostBuf2, buffers.scratch, buffers.size())) {
        std::cout << "FAILED TEST\n";
        std::cout << "Value read back does not match value written\n";
        return -1;
    }
    return 0;
}

/**
 * Trivial loopback example which runs OpenCL loopback kernel. Does not use OpenCL
 * runtime but directly exercises the HAL driver API.
 */


const static struct option long_options[] = {
    {"hal_driver",      required_argument, 0, 's'},
    {"bitstream",       required_argument, 0, 'k'},
    {"hal_logfile",     required_argument, 0, 'l'},
    {"alignment",       required_argument, 0, 'a'},
    {"device",          required_argument, 0, 'd'},
    {"verbose",         no_argument,       0, 'v'},
    {"help",            no_argument,       0, 'h'},
    {0, 0, 0, 0}
};

static void printHelp()
{
    std::cout << "usage: %s [options] -k <bitstream>\n\n";
    std::cout << "  -s <hal_driver>\n";
    std::cout << "  -k <bitstream>\n";
    std::cout << "  -l <hal_logfile>\n";
    std::cout << "  -a <alignment>\n";
    std::cout << "  -d <index>\n";
    std::cout << "  -v\n";
    std::cout << "  -h\n\n";
    std::cout << "* If HAL driver is not specified, application will try to find the HAL driver\n";
    std::cout << "  using XILINX_OPENCL and XCL_PLATFORM environment variables\n";
    std::cout << "* Bitstream is required\n";
    std::cout << "* HAL logfile is optional but useful for capturing messages from HAL driver\n";
}


int main(int argc, char** argv)
{
    std::string sharedLibrary;
    std::string bitstreamFile;
    std::string halLogfile;
    size_t alignment = 128;
    int option_index = 0;
    unsigned index = 0;
    bool verbose = false;
    int c;
    findSharedLibrary(sharedLibrary);
    while ((c = getopt_long(argc, argv, "s:k:l:a:d:vh", long_options, &option_index)) != -1)
    {
        switch (c)
        {
        case 0:
            if (long_options[option_index].flag != 0)
                break;
        case 's':
            sharedLibrary = optarg;
            break;
        case 'k':
            bitstreamFile = optarg;
            break;
        case 'l':
            halLogfile = optarg;
            break;
        case 'a':
            alignment = std::atoi(optarg);
            break;
        case 'd':
            index = std::atoi(optarg);
            break;
        case 'h':
            printHelp();
            return 0;
        case 'v':
            verbose = true;
            break;
        default:
            printHelp();
            return -1;
        }
    }

    (void)verbose;

    if (sharedLibrary.size() == 0) {
        std::cout << "FAILED TEST\n";
        std::cout << "No shared library specified and library couldnot be found using XILINX_OPENCL and XCL_PLATFORM environment variables\n";
        return -1;
    }

    if (bitstreamFile.size() == 0) {
        std::cout << "FAILED TEST\n";
        std::cout << "No bitstream specified\n";
        return -1;
    }

    if (halLogfile.size()) {
        std::cout << "Using " << halLogfile << " as HAL driver logfile\n";
    }

    std::cout << "HAL driver = " << sharedLibrary << "\n";
    std::cout << "Host buffer alignment = " << alignment << " bytes\n";
    std::cout << "Compiled kernel = " << bitstreamFile << "\n" << std::endl;

    try {
        xclHALProxy proxy(sharedLibrary.c_str(), bitstreamFile.c_str(), index, halLogfile.c_str());

        Buffers buf(alignment);
        if (setupBuffers(proxy, buf))
            return -1;

        AlignedAllocator<unsigned> regMap(alignment, 16);
        AlignedAllocator<unsigned> regMapReadBack(alignment, 16);

        std::memset(regMap.getBuffer(), 0, regMap.size());
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_AP_CTRL] = 0x0; // ap_start
#if defined(DSA64)
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S1_DATA/4] = buf.deviceBuf1 & 0xFFFFFFFF; // s1
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S1_DATA/4 + 1] = (buf.deviceBuf1 >> 32) & 0xFFFFFFFF; // s1
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S2_DATA/4] = buf.deviceBuf2 & 0xFFFFFFFF; // s2
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S2_DATA/4 + 1] = (buf.deviceBuf2 >> 32) & 0xFFFFFFFF; // s2
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_LENGTH_R_DATA/4] = buf.size(); // length
#else
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S1_DATA/4] = buf.deviceBuf1; // s1
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_S2_DATA/4] = buf.deviceBuf2; // s2
        regMap.getBuffer()[XLOOPBACK_CONTROL_ADDR_LENGTH_R_DATA/4] = buf.size(); // length
#endif

        std::cout << "Starting kernel..." << std::endl;
        // First dump the control registers
        size_t result = proxy.readControl(0, regMapReadBack.getBuffer(), 16 * 4);
        if (result != 64) {
            std::cout << "FAILED TEST\n";
            std::cout << "Write failed\n";
            return 1;
        }

        std::cout << "Uninitialized kernel register map" << std::endl;
        for (unsigned i = 0; i < 12; i++) {
            // Data upto 0x28 is relevant
            std::cout << "0x" << std::hex << i << " : 0x" << regMapReadBack.getBuffer()[i] << std::dec << std::endl;
        }

        // only 24 bytes is relevant rest is for padding to 32
        result = proxy.writeControl(0, regMap.getBuffer(), 64);
        if (result != 64) {
            std::cout << "FAILED TEST\n";
            std::cout << "Write failed\n";
            return 1;
        }

        // Now dump the control registers to verify the args were written
        result = proxy.readControl(0, regMapReadBack.getBuffer(), 64);
        if (result != 64) {
            std::cout << "FAILED TEST\n";
            std::cout << "Write failed\n";
            return 1;
        }

        std::cout << "Kernel register map" << std::endl;
        for (unsigned i = 0; i < 12; i++) {
            // Data upto 0x28 is relevant
            std::cout << "0x" << std::hex << i << " : 0x" << regMapReadBack.getBuffer()[i] << std::dec << std::endl;
        }

        // Next kickoff the kernel
        regMap.getBuffer()[0x00] = 0x1; // ap_start
        result = proxy.writeControl(0, regMap.getBuffer(), 64);
        if (result != 64) {
            std::cout << "FAILED TEST\n";
            std::cout << "Write failed\n";
            return 1;
        }

        // Next wait for done from kernel
        std::cout << "Waiting for kernel to finish..." << std::endl;
        bool flag = false;
        while (!flag) {
            sleep(1);
            std::memset(regMapReadBack.getBuffer(), 0, 64);
            result = proxy.readControl(0, regMapReadBack.getBuffer(), 64);
            if (result != 64) {
                std::cout << "FAILED TEST\n";
                std::cout << "Write failed\n";
                return 1;
            }
            flag = (regMapReadBack.getBuffer()[0] & 0x6);
            std::cout << "Kernel Status = 0x" << std::hex << regMapReadBack.getBuffer()[0] << std::dec << std::endl;
        }

        std::memset(buf.scratch, 0, buf.size());
        // Copy back the arg0 buffer and verify
        result = proxy.migrateDevice2Host(buf.deviceBuf1, buf.scratch, buf.size());

        if (std::memcmp(buf.scratch, buf.hostBuf2, buf.size())) {
            std::cout << "FAILED TEST\n";
            std::cout << "Value read back does not match value written\n";
            return 1;
        }
    }
    catch (std::exception const& e)
    {
        std::cout << "Exception: " << e.what() << "\n";
        std::cout << "FAILED TEST\n";
        return 1;
    }

    std::cout << "PASSED TEST\n";
    return 0;
}
